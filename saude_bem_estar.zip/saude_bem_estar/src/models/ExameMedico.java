package models;
/**
 *
 * @author julio
 */
public class ExameMedico {
    private int id;
    private String descricao;
    private String resultado;
    private int consultaMedicaId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getResultado() {
        return resultado;
    }

    public void setResultado(String resultado) {
        this.resultado = resultado;
    }

    public int getConsultaMedicaId() {
        return consultaMedicaId;
    }

    public void setConsultaMedicaId(int consultaMedicaId) {
        this.consultaMedicaId = consultaMedicaId;
    }
}

