package models;

import java.sql.Date;
import java.sql.Time;

/**
 *
 * @author julio
 */
public class Agenda {
    private int id;
    private Date data;
    private Time horario;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public Time getHorario() {
        return horario;
    }

    public void setHorario(Time horario) {
        this.horario = horario;
    } 
}

