package dao;
/**
 *
 * @author julio
 */
import database.Conexao;
import models.Agenda;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AgendaDAO {
    private Conexao conexao;
    private Connection conn;
    
    public AgendaDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }   
    // Método para inserir nova agenda
     public void inserirAgenda(Agenda agenda) {
        String sql = "INSERT INTO agenda (data, horario) VALUES (?, ?)";

        try (
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDate(1, agenda.getData());
            stmt.setTime(2, agenda.getHorario());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para listar todas as agendas
   public List<Agenda> listarAgendas() {
        List<Agenda> agendas = new ArrayList<>();
        String sql = "SELECT * FROM agenda"; 

        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Agenda agenda = new Agenda();
                agenda.setId(rs.getInt("id"));
                agenda.setData(rs.getDate("data"));
                agenda.setHorario(rs.getTime("horario"));
                agendas.add(agenda);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return agendas;
    }

    // Método para atualizar agenda
   public void atualizarAgenda(Agenda agenda) {
        String sql = "UPDATE agenda SET data = ?, horario = ? WHERE id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setDate(1, agenda.getData());
            stmt.setTime(2, agenda.getHorario());
            stmt.setInt(3, agenda.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para deletar agenda
     public void deletarAgenda(int id) {
        String sql = "DELETE FROM agenda WHERE id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
     }
        public Agenda getAgenda(int id) {
        Agenda agenda = null;
        String sql = "SELECT * FROM agenda WHERE id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                agenda = new Agenda();
                agenda.setId(rs.getInt("id"));
                agenda.setData(rs.getDate("data"));
                agenda.setHorario(rs.getTime("horario"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return agenda;
    }
    }

