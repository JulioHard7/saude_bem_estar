package dao;
/**
 *
 * @author julio
 */
import database.Conexao;
import models.Medicamento;

import java.sql.Connection;      
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MedicamentoDAO {
    private Conexao conexao;
    private Connection conn;
    
    public MedicamentoDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }
    
    // Método para inserir um novo medicamento
    public void inserirMedicamento(Medicamento medicamento) {
        String sql = "INSERT INTO medicamento (nome, dosagem) VALUES (?, ?)";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, medicamento.getNome());
            stmt.setString(2, medicamento.getDosagem());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para listar todos os medicamentos
    public List<Medicamento> listarMedicamentos() {
        List<Medicamento> medicamentos = new ArrayList<>();
        String sql = "SELECT * FROM medicamento";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                int id = rs.getInt("id");
                String nome = rs.getString("nome");
                String dosagem = rs.getString("dosagem");

                Medicamento medicamento = new Medicamento();
                medicamento.setId(id);
                medicamento.setNome(nome);
                medicamento.setDosagem(dosagem);

                medicamentos.add(medicamento);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return medicamentos;
    }

    // Método para atualizar um medicamento
    public void atualizarMedicamento(Medicamento medicamento) {
        String sql = "UPDATE medicamento SET nome = ?, dosagem = ? WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, medicamento.getNome());
            stmt.setString(2, medicamento.getDosagem());
            stmt.setInt(3, medicamento.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para deletar um medicamento
    public void deletarMedicamento(int id) {
        String sql = "DELETE FROM medicamento WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para buscar um medicamento específico
    public Medicamento getMedicamento(int id) {
        String sql = "SELECT * FROM medicamento WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                Medicamento medicamento = new Medicamento();
                medicamento.setId(rs.getInt("id"));
                medicamento.setNome(rs.getString("nome"));
                medicamento.setDosagem(rs.getString("dosagem"));

                return medicamento;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
