package dao;
/**
 *
 * @author julio
 */
import database.Conexao;
import models.HistoricoVacinacao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement; 
import java.util.ArrayList;
import java.util.List;

public class HistoricoVacinacaoDAO {
    private Conexao conexao;
    private Connection conn;
    
    public HistoricoVacinacaoDAO() {
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }

    // Método para inserir novo histórico de vacinação
    public void inserirHistoricoVacinacao(HistoricoVacinacao historicoVacinacao) {
        String sql = "INSERT INTO historico_vacinacao (vacina, data_aplicacao, usuario_id) VALUES (?, ?, ?)";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, historicoVacinacao.getVacina());
            stmt.setString(2, historicoVacinacao.getDataAplicacao()); // Use String para data_aplicacao
            stmt.setInt(3, historicoVacinacao.getUsuarioId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para listar todos os históricos de vacinação
    public List<HistoricoVacinacao> listarHistoricoVacinacao() {
        List<HistoricoVacinacao> historicos = new ArrayList<>();
        String sql = "SELECT * FROM historico_vacinacao";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("id");
                String vacina = rs.getString("vacina");
                String dataAplicacao = rs.getString("data_aplicacao"); 
                int usuarioId = rs.getInt("usuario_id");

                HistoricoVacinacao historicoVacinacao = new HistoricoVacinacao();
                historicoVacinacao.setId(id);
                historicoVacinacao.setVacina(vacina);
                historicoVacinacao.setDataAplicacao(dataAplicacao);
                historicoVacinacao.setUsuarioId(usuarioId);

                historicos.add(historicoVacinacao);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return historicos;
    }

    // Método para atualizar um histórico de vacinação
    public void atualizarHistoricoVacinacao(HistoricoVacinacao historicoVacinacao) {
        String sql = "UPDATE historico_vacinacao SET vacina = ?, data_aplicacao = ?, usuario_id = ? WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, historicoVacinacao.getVacina());
            stmt.setString(2, historicoVacinacao.getDataAplicacao()); 
            stmt.setInt(3, historicoVacinacao.getUsuarioId());
            stmt.setInt(4, historicoVacinacao.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para deletar um histórico de vacinação
    public void deletarHistoricoVacinacao(int id) {
        String sql = "DELETE FROM historico_vacinacao WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para buscar um histórico de vacinação específico
    public HistoricoVacinacao getHistoricoVacinacao(int id) {
        String sql = "SELECT * FROM historico_vacinacao WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                HistoricoVacinacao historicoVacinacao = new HistoricoVacinacao();
                historicoVacinacao.setId(rs.getInt("id"));
                historicoVacinacao.setVacina(rs.getString("vacina"));
                historicoVacinacao.setDataAplicacao(rs.getString("data_aplicacao")); 
                historicoVacinacao.setUsuarioId(rs.getInt("usuario_id"));

                return historicoVacinacao;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}

