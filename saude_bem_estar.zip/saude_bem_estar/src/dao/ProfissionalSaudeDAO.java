package dao;
/**
 *
 * @author julio
 */
import database.Conexao;
import models.ProfissionalSaude;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProfissionalSaudeDAO {
    private Conexao conexao;
    private Connection conn;
    
    public ProfissionalSaudeDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }
    
    // Método para inserir um novo profissional de saúde
    public void inserirProfissionalSaude(ProfissionalSaude profissional) {
        String sql = "INSERT INTO profissional_saude (nome, especialidade, crm, telefone) VALUES (?, ?, ?, ?)";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, profissional.getNome());
            stmt.setString(2, profissional.getEspecialidade());
            stmt.setString(3, profissional.getCrm());
            stmt.setString(4, profissional.getTelefone());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para listar todos os profissionais de saúde
    public List<ProfissionalSaude> listarProfissionaisSaude() {
        List<ProfissionalSaude> profissionais = new ArrayList<>();
        String sql = "SELECT * FROM profissional_saude";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                int id = rs.getInt("id");
                String nome = rs.getString("nome");
                String especialidade = rs.getString("especialidade");
                String crm = rs.getString("crm");
                String telefone = rs.getString("telefone");

                ProfissionalSaude profissional = new ProfissionalSaude();
                profissional.setId(id);
                profissional.setNome(nome);
                profissional.setEspecialidade(especialidade);
                profissional.setCrm(crm);
                profissional.setTelefone(telefone);

                profissionais.add(profissional);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return profissionais;
    }

    // Método para atualizar um profissional de saúde
    public void atualizarProfissionalSaude(ProfissionalSaude profissional) {
        String sql = "UPDATE profissional_saude SET nome = ?, especialidade = ?, crm = ?, telefone = ? WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, profissional.getNome());
            stmt.setString(2, profissional.getEspecialidade());
            stmt.setString(3, profissional.getCrm());
            stmt.setString(4, profissional.getTelefone());
            stmt.setInt(5, profissional.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para deletar um profissional de saúde
    public void deletarProfissionalSaude(int id) {
        String sql = "DELETE FROM profissional_saude WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para buscar um profissional de saúde específico
    public ProfissionalSaude getProfissionalSaude(int id) {
        String sql = "SELECT * FROM profissional_saude WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                ProfissionalSaude profissional = new ProfissionalSaude();
                profissional.setId(rs.getInt("id"));
                profissional.setNome(rs.getString("nome"));
                profissional.setEspecialidade(rs.getString("especialidade"));
                profissional.setCrm(rs.getString("crm"));
                profissional.setTelefone(rs.getString("telefone"));

                return profissional;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
