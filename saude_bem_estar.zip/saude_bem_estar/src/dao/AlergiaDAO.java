package dao;
/**
 *
 * @author julio
 */
import database.Conexao;
import models.Alergia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AlergiaDAO {
    private Conexao conexao;
    private Connection conn;
    
    public AlergiaDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }   
    // Método para inserir alergia
    public void inserirAlergia(Alergia alergia) {
        String sql = "INSERT INTO alergia (descricao, usuario_id) VALUES (?, ?)";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, alergia.getDescricao());
            stmt.setInt(2, alergia.getUsuarioId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para listar todas as alergias
    public List<Alergia> listarAlergias() {
        List<Alergia> alergias = new ArrayList<>();
        String sql = "SELECT * FROM alergia";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                int id = rs.getInt("id");
                String descricao = rs.getString("descricao");
                int usuarioId = rs.getInt("usuario_id");

                Alergia alergia = new Alergia();
                alergia.setId(id);
                alergia.setDescricao(descricao);
                alergia.setUsuarioId(usuarioId);

                alergias.add(alergia);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return alergias;
    }

    // Método para atualizar uma alergia
    public void atualizarAlergia(Alergia alergia) {
        String sql = "UPDATE alergia SET descricao = ?, usuario_id = ? WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, alergia.getDescricao());
            stmt.setInt(2, alergia.getUsuarioId());
            stmt.setInt(3, alergia.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para deletar uma alergia
    public void deletarAlergia(int id) {
        String sql = "DELETE FROM alergia WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para buscar uma alergia pelo id
    public Alergia getAlergia(int id) {
        String sql = "SELECT * FROM alergia WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                Alergia alergia = new Alergia();
                alergia.setId(rs.getInt("id"));
                alergia.setDescricao(rs.getString("descricao"));
                alergia.setUsuarioId(rs.getInt("usuario_id"));

                return alergia;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}

