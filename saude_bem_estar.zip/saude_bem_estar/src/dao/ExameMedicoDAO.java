package dao;
/**
 *
 * @author julio
 */
import database.Conexao;
import models.ExameMedico;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ExameMedicoDAO {
        private Conexao conexao;
    private Connection conn;
    
    public ExameMedicoDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }

    // Método para adicionar um novo exame médico
     public void inserirExameMedico(ExameMedico exameMedico) {
        String sql = "INSERT INTO exame_medico (descricao, resultado, consulta_medica_id) VALUES (?, ?, ?)";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, exameMedico.getDescricao());
            stmt.setString(2, exameMedico.getResultado());
            stmt.setInt(3, exameMedico.getConsultaMedicaId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para listar todos os exames médicos
    public List<ExameMedico> listarExameMedicos() {
        List<ExameMedico> examesMedicos = new ArrayList<>();
        String sql = "SELECT * FROM exame_medico";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                int id = rs.getInt("id");
                String descricao = rs.getString("descricao");
                String resultado = rs.getString("resultado");
                int consultaMedicaId = rs.getInt("consulta_medica_id");

                ExameMedico exameMedico = new ExameMedico();
                exameMedico.setId(id);
                exameMedico.setDescricao(descricao);
                exameMedico.setResultado(resultado);
                exameMedico.setConsultaMedicaId(consultaMedicaId);

                examesMedicos.add(exameMedico);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return examesMedicos;
    }

    // Método para atualizar um exame médico
    public void atualizarExameMedico(ExameMedico exameMedico) {
        String sql = "UPDATE exame_medico SET descricao = ?, resultado = ?, consulta_medica_id = ? WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, exameMedico.getDescricao());
            stmt.setString(2, exameMedico.getResultado());
            stmt.setInt(3, exameMedico.getConsultaMedicaId());
            stmt.setInt(4, exameMedico.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para deletar um exame médico
    public void deletarExameMedico(int id) {
        String sql = "DELETE FROM exame_medico WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para buscar um exame médico específico
    public ExameMedico getExameMedico(int id) {
        String sql = "SELECT * FROM exame_medico WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                ExameMedico exameMedico = new ExameMedico();
                exameMedico.setId(rs.getInt("id"));
                exameMedico.setDescricao(rs.getString("descricao"));
                exameMedico.setResultado(rs.getString("resultado"));
                exameMedico.setConsultaMedicaId(rs.getInt("consulta_medica_id"));

                return exameMedico;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
