package dao;

import database.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import models.Endereco;
import java.util.List;

/**
 *
 * @author julio
 */
public class EnderecoDAO {
     private Conexao conexao;
    private Connection conn;
    
    public EnderecoDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }
     // Método para inserir um endereço
    public void inserirEndereco(Endereco endereco) {
        String sql = "INSERT INTO endereco (usuario_id, rua, cidade, estado) VALUES (?, ?, ?, ?)";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, endereco.getUsuarioId());
            stmt.setString(2, endereco.getRua());
            stmt.setString(3, endereco.getCidade());
            stmt.setString(4, endereco.getEstado());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para listar todos os endereços
    public List<Endereco> listarEnderecos() {
        List<Endereco> enderecos = new ArrayList<>();
        String sql = "SELECT * FROM endereco";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Endereco endereco = new Endereco();
                endereco.setId(rs.getInt("id"));
                endereco.setUsuarioId(rs.getInt("usuario_id"));
                endereco.setRua(rs.getString("rua"));
                endereco.setCidade(rs.getString("cidade"));
                endereco.setEstado(rs.getString("estado"));

                enderecos.add(endereco);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return enderecos;
    }

    // Método para atualizar um endereço
    public void atualizarEndereco(Endereco endereco) {
        String sql = "UPDATE endereco SET rua = ?, cidade = ?, estado = ?, usuario_id = ? WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, endereco.getRua());
            stmt.setString(2, endereco.getCidade());
            stmt.setString(3, endereco.getEstado());
            stmt.setInt(4, endereco.getUsuarioId());
            stmt.setInt(5, endereco.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para deletar um endereço
    public void deletarEndereco(int id) {
        String sql = "DELETE FROM endereco WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para buscar um endereço específico por ID
    public Endereco getEndereco(int id) {
        String sql = "SELECT * FROM endereco WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                Endereco endereco = new Endereco();
                endereco.setId(rs.getInt("id"));
                endereco.setUsuarioId(rs.getInt("usuario_id"));
                endereco.setRua(rs.getString("rua"));
                endereco.setCidade(rs.getString("cidade"));
                endereco.setEstado(rs.getString("estado"));

                return endereco;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}

