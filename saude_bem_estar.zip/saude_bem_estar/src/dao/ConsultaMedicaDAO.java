package dao;
/**
 *
 * @author julio
 */
import database.Conexao;
import models.ConsultaMedica;

import java.sql.Connection;      
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List; 

public class ConsultaMedicaDAO {
    private Conexao conexao;
    private Connection conn;
    
    public ConsultaMedicaDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
    }
    // Método para inserir nova consulta médica
    public void inserirConsultaMedica(ConsultaMedica consultaMedica) {
        String sql = "INSERT INTO consulta_medica (usuario_id, profissional_saude_id, agenda_id, descricao) VALUES (?, ?, ?, ?)";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, consultaMedica.getUsuarioId());
            stmt.setInt(2, consultaMedica.getProfissionalSaudeId());
            stmt.setInt(3, consultaMedica.getAgendaId());
            stmt.setString(4, consultaMedica.getDescricao());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para listar todas as consultas médicas
    public List<ConsultaMedica> listarConsultasMedicas() {
        List<ConsultaMedica> consultasMedicas = new ArrayList<>();
        String sql = "SELECT * FROM consulta_medica";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                int id = rs.getInt("id");
                int usuarioId = rs.getInt("usuario_id");
                int profissionalSaudeId = rs.getInt("profissional_saude_id");
                int agendaId = rs.getInt("agenda_id");
                String descricao = rs.getString("descricao");

                ConsultaMedica consultaMedica = new ConsultaMedica();
                consultaMedica.setId(id);
                consultaMedica.setUsuarioId(usuarioId);
                consultaMedica.setProfissionalSaudeId(profissionalSaudeId);
                consultaMedica.setAgendaId(agendaId);
                consultaMedica.setDescricao(descricao);

                consultasMedicas.add(consultaMedica);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return consultasMedicas;
    }

    // Método para atualizar uma consulta médica
    public void atualizarConsultaMedica(ConsultaMedica consultaMedica) {
        String sql = "UPDATE consulta_medica SET usuario_id = ?, profissional_saude_id = ?, agenda_id = ?, descricao = ? WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, consultaMedica.getUsuarioId());
            stmt.setInt(2, consultaMedica.getProfissionalSaudeId());
            stmt.setInt(3, consultaMedica.getAgendaId());
            stmt.setString(4, consultaMedica.getDescricao());
            stmt.setInt(5, consultaMedica.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para deletar uma consulta médica
    public void deletarConsultaMedica(int id) {
        String sql = "DELETE FROM consulta_medica WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Método para buscar uma consulta médica pelo id
    public ConsultaMedica getConsultaMedica(int id) {
        String sql = "SELECT * FROM consulta_medica WHERE id = ?";
        try {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                ConsultaMedica consultaMedica = new ConsultaMedica();
                consultaMedica.setId(rs.getInt("id"));
                consultaMedica.setUsuarioId(rs.getInt("usuario_id"));
                consultaMedica.setProfissionalSaudeId(rs.getInt("profissional_saude_id"));
                consultaMedica.setAgendaId(rs.getInt("agenda_id"));
                consultaMedica.setDescricao(rs.getString("descricao"));

                return consultaMedica;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}

