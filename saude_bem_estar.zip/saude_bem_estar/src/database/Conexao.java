package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 *
 * @author julio
 */
public class Conexao {
   
    public Connection getConexao(){
        try{
            Connection conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/saude_bem_estar", 
                    "root", 
                    "");
            return conn;
        }catch(Exception e){
            System.out.println("Erro de conexão: "+ e.getMessage());
            return null;
        }
    }
   
}
